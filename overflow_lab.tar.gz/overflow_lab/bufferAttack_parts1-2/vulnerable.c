/* 
 *
 * $Id: vulnerable.c,v 1.4 2003/09/15 16:36:15 schallee Exp $
 *
 * see end of file for copyright info
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#include "lab7.h"

/*
 * use asm to get stack pointer and return it
 * this generates a warning since the compiler doesn't see a return
 */
unsigned int get_sp(void)
{
	unsigned int ret;
	__asm__("movl %%esp, %0" : "=g" (ret));
	return ret;
}

/*
 * dummy function to jump to
 */
void exploited(void)
{
	printf("Exploit sucsessful!\n");

	/* a clean exit is nice */
	exit(0);
}

/*
 * vulnerable function for exploiting
 */
void vulnerable (int first, char * string, int third) {
	char buf[buffer_size]={'a','b','c','d'};
	int dummy2;

	dummy2 = 10;
	strcpy(buf, string);
	printf("Inside of vulnerable function: buf in here is %s\n", buf);
}

/*
 * program usage
 */
void usage(char *name) {
	char *basename;

	basename = rindex(name, '/');
	if(!basename)
		basename = name;
	fprintf(stderr, "\nusage: .%s [-sm] [string] \n\n", basename);
	fprintf(stderr, "\t-s print stack pointer and exit\n"
			"\t-m do not monge stack pointer to static value\n\n");
	exit(1);
}

/*
 * main
 */
int main(int argc, char **argv)
{
	int dummy1;
	unsigned int sp;
	extern int optind;
	char ch;
	unsigned int print_sp = false;
	unsigned int monge_sp = true;

	/*get stack pinter */
	sp = get_sp();

	/* parse command line */
	while ((ch = getopt(argc, argv, "sm")) != -1) {
		switch(ch)
		{
			case 's':
				print_sp = true;
			break;
			case 'm':
				monge_sp = false;
			break;
         
		}
	}

	/* monge sp unless requested not to */
	if(monge_sp)
		alloca((sp - LOW_SP) + SP_OFFSET);

	/* print sp and exit if requested */
	if(print_sp) {
		sp = get_sp();
		printf("Stack pointer is 0x%08x (%u)\n", sp, sp);
		exit(0);
	}

	/* make sure we have a string */
	if(argc - 1 != optind) {
		usage(argv[0]);
      exit(0);
   }
   
	/*run test code */
	dummy1=7;
	vulnerable(12,argv[optind],14);
	printf("dummy is %d\n", dummy1);

	/* exit */
	return 0;
}

/* This file is part of BYU CS 465 Lab 1.
 *
 * Copyright 2003 Ed schaller <schallee@darkmist.net>
 *
 * This lab is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * lab1 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with lab1; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
