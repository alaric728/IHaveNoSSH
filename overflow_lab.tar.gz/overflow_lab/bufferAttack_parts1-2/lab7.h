/* 
 *
 * $Id: lab1.h,v 1.4 2003/09/15 16:36:15 schallee Exp $
 *
 * see end of file for copyright info
 *
 */

#ifndef lab1_h
#define lab1_h

#define prog_path "./vulnerable"
#define buffer_size 8

/* assembly definitions */
#define nop (char)0x90

/* binary instruction to jump one word forward */
char jump_word[] = "\xEB\x04";

/*
 * sp_monge defaults
 */
#define LOW_SP		0xBF7FD678
#define SP_OFFSET	0xFF

/*
 * useful defines
 */
#ifndef false
#	define false 0
#endif
#ifndef true
#	define true ~0
#endif

#endif
/* This file is part of BYU CS 465 Lab 1.
 *
 * Copyright 2003 Ed schaller <schallee@darkmist.net>
 *
 * This lab is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * lab1 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with lab1; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
