    /* 
    * Just the vulnerable program we will exploit.
    * Compile as: gcc -o vulnerable_heap vulnerable.c 
    */

   #include <stdio.h>
   #include <stdlib.h>
   #include <unistd.h>
   #include <string.h>

   #define ERROR -1
   #define BUFSIZE 64

   int goodfunc(const char *str); /* funcptr starts out as this */

   int main(int argc, char **argv)
   {
      static int (*funcptr)(const char *str);/* funcptr that can be changed, so that it points to system (or anywhere else) */
      static char buf[BUFSIZE];/* buffer that can be overflowed into the function pointer funcptr */

      printf("Vulnerable program is running*******************\n");
      
      if (argc <= 2) {
         fprintf(stderr, "Usage: %s <buf> <arg for goodfunc>\n", argv[0]);
         exit(ERROR);
      }

      printf("This is the address of the function system() = %p\n", system);
      
      funcptr = (int (*)(const char *str))goodfunc; /* checking the address of funcptr */
      printf("Before heap overflow, funcptr points to %p\n", funcptr);

      memset(buf, 0, sizeof(buf)); /* zero out the vulnerable buf that can be overflowed */
      strncpy(buf, argv[1], strlen(argv[1])); /* copy argv[1] into the buffer buf (there is no check on the size of argv[1] */
      printf("After heap overflow: funcptr points to %p\n", funcptr);

      /*call the function at funcptr with argument argv[2]*/
      (void)(*funcptr)(argv[2]);
      
      printf("Vulnerable program is done************************\n");
      
      return 0;
   }

   
   
   /* This is what funcptr would point to if we didn't overflow it in the heap */
   int goodfunc(const char *str)
   {
      printf("\nHi, I'm a good function.  I was passed: %s\n", str);
      return 0;
   }
